

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Default Datatable</h4>
                <p class="card-title-desc">DataTables has most features enabled by
                    default, so all you need to do to use it with your own tables is to call
                    the construction function: <code>$().DataTable();</code>.
                </p>
                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Category Name</th>
                            <th>Sub Category Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($subcategory->category->name); ?></td>
                            <td><?php echo e($subcategory->name); ?></td>
                            <td><?php echo e($subcategory->description); ?></td>
                            <td>
                                <img src="<?php echo e(asset($subcategory->image)); ?>" alt="" height="50" width="80" />
                            </td>
                            <td><?php echo e($subcategory->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                            <td>
                            <a href="<?php echo e(route('subcategory.edit', ['id' => $subcategory->id])); ?>" class="btn btn-success btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>
                                
                                <a href="" class="btn btn-danger btn-sm" onclick="event.preventDefault(); document.getElementById('subCategoryDeleteForm<?php echo e($subcategory->id); ?>').submit();">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <form action="<?php echo e(route('subcategory.delete', ['id' => $subcategory->id])); ?>" method="POST" id="subCategoryDeleteForm<?php echo e($subcategory->id); ?>">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\day-20\resources\views/admin/subcategory/manage.blade.php ENDPATH**/ ?>