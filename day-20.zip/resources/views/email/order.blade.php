<h1>{{$data['title']}}</h1>
<h2>Welcome {{$data['name']}}, Congratulation for your order.</h2>
<h1>Your Total Order : {{$data['total']}}</h1>
<p>Thank You.</p>
